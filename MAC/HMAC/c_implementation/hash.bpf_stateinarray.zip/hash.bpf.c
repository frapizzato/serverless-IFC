//#include <linux/bpf.h>
//#include "/home/id03141/libbpf/include/uapi/linux/bpf.h"
//#include "/usr/local/include/bpf/bpf.h"
//#include <linux/if_ether.h>
//#include <linux/if_packet.h>
//#include <linux/ip.h>
#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_core_read.h>
#include "hash.bpf.h"


SEC("xdp")
int keccak_xdp(struct xdp_md *ctx) {
    unsigned int rateInBytes = RATE / 8;
    unsigned int blockSize = 0;
    unsigned int i = 0;
    unsigned char delimitedSuffix = 0x06;

    unsigned int round, x, y, j, t;
    uint8_t LFSRstate = 0x01;

    __u8 state[STATE_LEN] = {0};

    // Fixed input string for hashing
    const unsigned char input[] = "Hello, eBPF! I am a string that will be hashed by Keccak. Remember that the input lenght must be higher than the rate if we want to perform the Keccak permutation in the absorbing phase.";
    int inputByteLen = sizeof(input) - 1;
    //bpf_printk("inputByteLen: %d\n", inputByteLen);

    // Output buffer length (arbitrary, here for demo purposes)
    unsigned long long int outputByteLen = 32;
    __u8 outputDigest[32] = {0};
    unsigned int outputDigestStartIndex = 0;

    if (inputByteLen > MAX_LEN) {
        bpf_printk("Input too long\n");
        return XDP_PASS;
    }

    // Absorb the input into the Keccak state
    __u8 offset = 0;
    

    while (inputByteLen > 0) {
        blockSize = MIN(inputByteLen, rateInBytes);
        
        for (i = 0; i < blockSize; i++) {
            //bpf_printk("input[i]: %d\n", input[i]);
            __u8 index = offset + i;
            //lookupVal = bpf_map_lookup_elem(&keccak_state_map, &index);
            //if (!lookupVal) continue;
            state[index] = state[index] ^ input[index];
        }

        offset += blockSize;
        inputByteLen -= blockSize;
    

        if (blockSize == rateInBytes) {
            // Apply Keccak permutation
            //int res = KeccakF1600_StatePermute(state);

            for(round=0; round<24; round++) {
                {   /* === θ step (see [Keccak Reference, Section 2.3.2]) === */
                    __u64 C[5], D;

                    /* Compute the parity of the columns */
                    for(x=0; x<5; x++)
                        C[x] = readLane(x, 0) ^ readLane(x, 1) ^ readLane(x, 2) ^ readLane(x, 3) ^ readLane(x, 4);
                    for(x=0; x<5; x++) {
                        /* Compute the θ effect for a given column */
                        D = C[(x+4)%5] ^ ROL64(C[(x+1)%5], 1);
                        /* Add the θ effect to the whole column */
                        for (y=0; y<5; y++)
                            XORLane(x, y, D);
                    }
                }

                {   /* === ρ and π steps (see [Keccak Reference, Sections 2.3.3 and 2.3.4]) === */
                    __u64 current, temp;
                    /* Start at coordinates (1 0) */
                    x = 1; y = 0;
                    current = readLane(x, y);
                    /* Iterate over ((0 1)(2 3))^t * (1 0) for 0 ≤ t ≤ 23 */
                    for(t=0; t<24; t++) {
                        /* Compute the rotation constant r = (t+1)(t+2)/2 */
                        unsigned int r = ((t+1)*(t+2)/2)%64;
                        /* Compute ((0 1)(2 3)) * (x y) */
                        unsigned int Y = (2*x+3*y)%5; x = y; y = Y;
                        /* Swap current and state(x,y), and rotate */
                        if (i(x, y) < STATE_LEN) 
                        {
                            temp = readLane(x, y);
                            writeLane(x, y, ROL64(current, r));
                            current = temp;
                        }
                        else
                        {
                            bpf_printk("Index out of bounds\n");
                            return XDP_PASS;
                        }
                    }
                }

                {   /* === χ step (see [Keccak Reference, Section 2.3.1]) === */
                    __u64 temp[5];
                    for(y=0; y<5; y++) {
                        /* Take a copy of the plane */
                        for(x=0; x<5; x++)
                            temp[x] = readLane(x, y);
                        /* Compute χ on the plane */
                        for(x=0; x<5; x++)
                            writeLane(x, y, temp[x] ^((~temp[(x+1)%5]) & temp[(x+2)%5]));
                    }
                }

                {   /* === ι step (see [Keccak Reference, Section 2.3.5]) === */
                    for(j=0; j<7; j++) {
                        unsigned int bitPosition = (1<<j)-1; /* 2^j-1 */
                        if (LFSR86540(&LFSRstate))
                            XORLane(0, 0, (__u64)1<<bitPosition);
                    }
                }
            }

            blockSize = 0;
        }
        
    }

    // Padding
    unsigned int padIndex = offset;
    state[blockSize] ^= delimitedSuffix;
    if (((delimitedSuffix & 0x80) != 0) && (blockSize == (rateInBytes-1))) {
        //KeccakF1600_StatePermute(state);
        for(round=0; round<24; round++) {
            {   /* === θ step (see [Keccak Reference, Section 2.3.2]) === */
                __u64 C[5], D;

                /* Compute the parity of the columns */
                for(x=0; x<5; x++)
                    C[x] = readLane(x, 0) ^ readLane(x, 1) ^ readLane(x, 2) ^ readLane(x, 3) ^ readLane(x, 4);
                for(x=0; x<5; x++) {
                    /* Compute the θ effect for a given column */
                    D = C[(x+4)%5] ^ ROL64(C[(x+1)%5], 1);
                    /* Add the θ effect to the whole column */
                    for (y=0; y<5; y++)
                        XORLane(x, y, D);
                }
            }

            {   /* === ρ and π steps (see [Keccak Reference, Sections 2.3.3 and 2.3.4]) === */
                __u64 current, temp;
                /* Start at coordinates (1 0) */
                x = 1; y = 0;
                current = readLane(x, y);
                /* Iterate over ((0 1)(2 3))^t * (1 0) for 0 ≤ t ≤ 23 */
                for(t=0; t<24; t++) {
                    /* Compute the rotation constant r = (t+1)(t+2)/2 */
                    unsigned int r = ((t+1)*(t+2)/2)%64;
                    /* Compute ((0 1)(2 3)) * (x y) */
                    unsigned int Y = (2*x+3*y)%5; x = y; y = Y;
                    /* Swap current and state(x,y), and rotate */
                    if (i(x, y) < STATE_LEN) 
                    {
                        temp = readLane(x, y);
                        writeLane(x, y, ROL64(current, r));
                        current = temp;
                    }
                    else
                    {
                        bpf_printk("Index out of bounds\n");
                        return XDP_PASS;
                    }
                }
            }

            {   /* === χ step (see [Keccak Reference, Section 2.3.1]) === */
                __u64 temp[5];
                for(y=0; y<5; y++) {
                    /* Take a copy of the plane */
                    for(x=0; x<5; x++)
                        temp[x] = readLane(x, y);
                    /* Compute χ on the plane */
                    for(x=0; x<5; x++)
                        writeLane(x, y, temp[x] ^((~temp[(x+1)%5]) & temp[(x+2)%5]));
                }
            }

            {   /* === ι step (see [Keccak Reference, Section 2.3.5]) === */
                for(j=0; j<7; j++) {
                    unsigned int bitPosition = (1<<j)-1; /* 2^j-1 */
                    if (LFSR86540(&LFSRstate))
                        XORLane(0, 0, (__u64)1<<bitPosition);
                }
            }
        }

            blockSize = 0;
    }
    
    state[rateInBytes-1] ^= 0x80;
    for(round=0; round<24; round++) {
        {   /* === θ step (see [Keccak Reference, Section 2.3.2]) === */
            __u64 C[5], D;

            /* Compute the parity of the columns */
            for(x=0; x<5; x++)
                C[x] = readLane(x, 0) ^ readLane(x, 1) ^ readLane(x, 2) ^ readLane(x, 3) ^ readLane(x, 4);
            for(x=0; x<5; x++) {
                /* Compute the θ effect for a given column */
                D = C[(x+4)%5] ^ ROL64(C[(x+1)%5], 1);
                /* Add the θ effect to the whole column */
                for (y=0; y<5; y++)
                    XORLane(x, y, D);
            }
        }

        {   /* === ρ and π steps (see [Keccak Reference, Sections 2.3.3 and 2.3.4]) === */
            __u64 current, temp;
            /* Start at coordinates (1 0) */
            x = 1; y = 0;
            current = readLane(x, y);
            /* Iterate over ((0 1)(2 3))^t * (1 0) for 0 ≤ t ≤ 23 */
            for(t=0; t<24; t++) {
                /* Compute the rotation constant r = (t+1)(t+2)/2 */
                unsigned int r = ((t+1)*(t+2)/2)%64;
                /* Compute ((0 1)(2 3)) * (x y) */
                unsigned int Y = (2*x+3*y)%5; x = y; y = Y;
                /* Swap current and state(x,y), and rotate */
                if (i(x, y) < STATE_LEN) 
                {
                    temp = readLane(x, y);
                    writeLane(x, y, ROL64(current, r));
                    current = temp;
                }
                else
                {
                    bpf_printk("Index out of bounds\n");
                    return XDP_PASS;
                }
            }
        }

        {   /* === χ step (see [Keccak Reference, Section 2.3.1]) === */
            __u64 temp[5];
            for(y=0; y<5; y++) {
                /* Take a copy of the plane */
                for(x=0; x<5; x++)
                    temp[x] = readLane(x, y);
                /* Compute χ on the plane */
                for(x=0; x<5; x++)
                    writeLane(x, y, temp[x] ^((~temp[(x+1)%5]) & temp[(x+2)%5]));
            }
        }

        {   /* === ι step (see [Keccak Reference, Section 2.3.5]) === */
            for(j=0; j<7; j++) {
                unsigned int bitPosition = (1<<j)-1; /* 2^j-1 */
                if (LFSR86540(&LFSRstate))
                    XORLane(0, 0, (__u64)1<<bitPosition);
            }
        }

        blockSize = 0;
    }

    // Output
    while (outputByteLen > 0) {
        blockSize = MIN(outputByteLen, rateInBytes);
        for (i = outputDigestStartIndex; i < outputDigestStartIndex + blockSize; i++) {
            unsigned int index = i % STATE_LEN;
            outputDigest[i] = state[index];
        }
        outputDigestStartIndex += blockSize;
        outputByteLen -= blockSize;

        if (outputByteLen > 0) {
            int res = KeccakF1600_StatePermute(state);  //state is stored inside the hash map, each byte is a state_byte struct, 200 bytes in total
        }
    }

    // Log the state
    bpf_printk("Keccak state:");
    __u8 value = 0;
    for (i = 0; i < 32; i++) {
        value = outputDigest[i]; 
        bpf_printk("%02x", value);
    }
 
    return XDP_PASS;
}


char LICENSE[] SEC("license") = "GPL";