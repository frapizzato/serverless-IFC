#define RATE 1088  // Example rate in bits
#define CAPACITY 512  // Example capacity in bits
#define DELIMITED_SUFFIX 0x06  // Delimited suffix value
#define STATE_LEN 200  // State length in bytes
#define MAX_LEN 400  // Maximum input length in bytes

#define MIN(a, b) ((a) < (b) ? (a) : (b))

#define ROL64(a, offset) ((((__u64)a) << offset) ^ (((__u64)a) >> (64-offset)))
#define i(x, y) ((x)+5*(y))

#define readLane(x, y)          (((__u64 *)state)[i(x, y)])
#define writeLane(x, y, lane)   (((__u64 *)state)[i(x, y)]) = (lane)
#define XORLane(x, y, lane)     (((__u64 *)state)[i(x, y)]) ^= (lane)

int LFSR86540(__u8 *LFSR)
{
    int result = ((*LFSR) & 0x01) != 0;
    if (((*LFSR) & 0x80) != 0)
        /* Primitive polynomial over GF(2): x^8+x^6+x^5+x^4+1 */
        (*LFSR) = ((*LFSR) << 1) ^ 0x71;
    else
        (*LFSR) <<= 1;
    return result;
}
